void aclog(const char * msg);
void aclogN(const char * msg, int n);